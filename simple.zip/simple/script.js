// ==========================PROGRESS JS
document.addEventListener("DOMContentLoaded", function (){
    let calcScrollValue = () => {
        let scrollProgress = document.getElementById("progress");
        let progressValue = document.getElementById("progress-value");
        let pos = document.documentElement.scrollTop;
        let calcHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        let scrollValue = Math.round((pos * 100) / calcHeight);
        if(pos > 190){
            scrollProgress.style.display = "grid";
        } else {
            scrollProgress.style.display = "none";
        }
        scrollProgress.addEventListener("click", () => {
            document.documentElement.scrollTop = 0;
        });
        scrollProgress.style.background = `conic-gradient(var(--themeColor) ${scrollValue}%, #00000071 ${scrollValue}%)`;
    };
  
    window.onscroll = calcScrollValue;
    window.onload = calcScrollValue;
  });



/*  -------------------------------------------- toggle style switcher -----------------------------------------*/
document.addEventListener("DOMContentLoaded", function(){
    const styleSwitcherToggle = document.querySelector(".style-switcher-toggler");
    styleSwitcherToggle.addEventListener("click", () => {
      document.querySelector(".style-switcher").classList.toggle("open");
    });
  
    window.addEventListener("scroll", () => {
      if(document.querySelector(".style-switcher").classList.contains("open")){
        document.querySelector(".style-switcher").classList.remove(".open");
      }
    });
  
    
  /* .............................THEME COLOR.................................... */
  const alternateStyles = document.querySelectorAll(".alternate-style");
  function setActiveStyle(color){
      alternateStyles.forEach((style) => {
          if(color === style.getAttribute("title")){
              style.removeAttribute('disabled');
          }else{
              style.setAttribute('disabled','true');
          }
      })
  }
   
  
  })
  
  
  let buttons = document.querySelectorAll(".color");
  for (var button of buttons) {
    button.addEventListener("click", (e) => {
      let target = e.target;
      let open = document.querySelector(".open");
      buttons.forEach((btn) => {
        btn.classList.remove("active");
      });
      target.classList.add("active");
  
      // ---------------------------------------------------
      let root = document.querySelector(":root"),
        dataColor = target.getAttribute("data-color"),
        color = dataColor.split(" ");
    });
  }
  
  console.log(buttons);


  document.addEventListener('DOMContentLoaded', function () {
    const waveElement = document.querySelector('.wave');
    const circleElement = document.querySelector('.circle');
    const wave1Element = document.querySelector('.wave1');
    const wave2Element = document.querySelector('.wave2');
    const changeBackgroundButton = document.getElementById('day-night');

    changeBackgroundButton.addEventListener('click', function () {
        // Change the background image URL
        waveElement.style.backgroundImage = 'url(waveiii.png)';
        wave1Element.style.opacity = '.2';
        wave2Element.style.opacity = '0.5';
        waveElement.style.opacity = '1';
        // circleElement.style.background = 'linear-gradient(to top left, white, var(--uniqueGree))'
    });





    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        } else {
          entry.target.classList.remove('show');
        }
      });
    });
    
    const hiddenElements = document.querySelectorAll('.hidden');
    const hidden1Elements = document.querySelectorAll('.hidden1');
    const hidden2Elements = document.querySelectorAll('.hidden2');
    hiddenElements.forEach((el) => observer.observe(el));
    hidden1Elements.forEach((el) => observer.observe(el));
    hidden2Elements.forEach((el) => observer.observe(el));
});



    // create instance of kinet with custom settings
    const circle = document.getElementById('follower');
    const sparkles = document.querySelectorAll('.sparkle');
  
    document.addEventListener('mousemove', (e) => {
      const mouseX = e.clientX;
      const mouseY = e.clientY;
  
      // Set the circle's position to follow the mouse
      circle.style.left = mouseX + 'px';
      circle.style.top = mouseY + 'px';
  
      // Set the sparkle positions
      sparkles.forEach((sparkle, index) => {
        const angle = (index / sparkles.length) * 360; // Distribute sparkles evenly in a circle
        const radius = 30; // Adjust the radius as needed
  
        const x = mouseX + radius * Math.cos((angle * Math.PI) / 180);
        const y = mouseY + radius * Math.sin((angle * Math.PI) / 180);
  
        sparkle.style.left = x + 'px';
        sparkle.style.top = y + 'px';
      });
    });


    